package com.company;

import java.io.*;
import java.util.*;

public class Main {
    public static char decode(char c) {
        int code, binaryLength;
        String binaryCode, newBinaryCode;
        code = (int) c; // Kod znaku w tablicy ASCII
        binaryCode = Integer.toBinaryString(code);
        binaryLength = binaryCode.length();

        newBinaryCode = binaryCode.substring(0, binaryLength-4) + binaryCode.charAt(binaryLength-1) + binaryCode.charAt(binaryLength-2) + binaryCode.charAt(binaryLength-3) + binaryCode.charAt(binaryLength-4);
        return (char) Integer.parseInt(newBinaryCode, 2);
    }

    public static void main(String[] args) {
        int i, j, code, binaryLength, decodedChar;
        String binaryCode, newBinaryCode;
        /* Iterujemy po kolejnych slowach */
        for(i=0; i<args.length; i++) {
            /* Iterujemy po kolejnych literach slowa */
            for(j=0; j<args[i].length(); j++) {
                  System.out.print(decode(args[i].charAt(j)));
            }
           /* Spacja to numer 32 w tabeli ASCII, czyli 100000 binarnie - kodowanie nic nie zmienia (cztery ostatnie bity takie same) */
            System.out.print(" ");
        }
    }
}
