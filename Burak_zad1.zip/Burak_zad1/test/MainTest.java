import com.company.Main;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {
    /* Dla spacji powinno zwrócić spację (cztery najmniej znaczace bity 32 to zera) */
    @Test
    void getSpace() {
        assertEquals(' ', Main.decode(' '));
    }

    /* Male a to w ASCII numer 97, binarnie - 1100001, po zakodowaniu - 1101000 binarnie, 104 dziesietnie - h */
    @Test
    void getA() {
        assertEquals('h', Main.decode('a'));
    }
}