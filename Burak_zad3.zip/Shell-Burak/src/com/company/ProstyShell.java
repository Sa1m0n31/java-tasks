package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class ProstyShell {
    /* Pola */
    private String cwd;

    /* Konstruktor */
    ProstyShell() {
        File currentDirectory = new File(".");
        String absolutePath = currentDirectory.getAbsolutePath();
        this.cwd = absolutePath.substring(0, absolutePath.length()-2);
    }

    /* Metody pomocnicze */
    boolean isInCurrentDirectory(String fileString) {
        File currentDirectory = new File(cwd);
        for(File file : currentDirectory.listFiles()) {
            if(file.getName().equals(fileString)) return true;
        }
        return false;
    }

    private boolean isDirectory(String fileString) {
        File fileToCheck = new File(cwd + "\\" + fileString);
        return fileToCheck.isDirectory();
    }

    /* Metody poszczegolnych komend */
    private void pwd(String[] nextLineArray) {
        if(nextLineArray.length == 1) System.out.println(cwd);
        else System.out.println("pwd - niepoprawna liczba argumentow");
    }

    private void ls(String[] nextLineArray) {
        if(nextLineArray.length == 1) {
            File directory = new File(cwd);
            StringBuilder allFiles = new StringBuilder();
            for(File file : directory.listFiles()) {
                allFiles.append(file.getName());
                allFiles.append("  ");
            }
            System.out.println(allFiles);
        }
        else {
            System.out.println("ls - niepoprawna liczba argumentow");
        }
    }

    private void cd(String[] nextLineArray) {
        if(nextLineArray.length == 2) {
            String directoryToChange = nextLineArray[1];
            if(directoryToChange.equals("..")) {
                /* Dzielimy cwd na czesci */
                String separator = "\\";
                String[] cwdArray = cwd.split(Pattern.quote(separator));

                /* Dodajemy kolejne czesci z wyjatkiem ostatniej do nowego cwd */
                StringBuilder newCwd = new StringBuilder();
                for(int i=0; i<cwdArray.length-1; i++) {
                    newCwd.append(cwdArray[i]);
                    newCwd.append(separator);
                }
                cwd = newCwd.substring(0, newCwd.length()-1);
            }
            else if((isInCurrentDirectory(directoryToChange))&&(isDirectory(directoryToChange))) {
                cwd += "\\" + directoryToChange;
            }
            else if(directoryToChange.equals(".")) {
                /* Pozostajemy w biezacym katalogu */
            }
            else {
                System.out.println("Nie znaleziono katalogu " + directoryToChange);
            }
        }
        else {
            System.out.println("cd - niepoprawna liczba argumentow");
        }
    }

    private void cat(String[] nextLineArray) {
        if(nextLineArray.length == 2) {
            try(BufferedReader fileToRead = new BufferedReader(new FileReader(cwd + "\\" + nextLineArray[1]))) {
                String line;
                while((line = fileToRead.readLine()) != null) {
                    System.out.println(line);
                }
            }
            catch(IOException ioException) {
                System.out.println("Plik o podanej nazwie nie istnieje");
            }
        }
        else {
            System.out.println("cat - niepoprawna liczba argumentow");
        }
    }

    private void history(ArrayList<String> commandsList) {
        for(String previousCommand : commandsList) {
            System.out.println(previousCommand);
        }
    }

    private void echo(String nextLine) {
        /* Wypisujemy linie od szostego znaku (znaku o indeksie 5) - pomijamy 'echo' oraz spacje */
        System.out.println(nextLine.substring(5));
    }

    private void cp(String[] nextLineArray) {
        /* Sprawdzamy czy podano jako parametry dwa pliki - plik z ktorego kopiujemy oraz plik do ktorego kopiujemy */
        if(nextLineArray.length == 3) {
            try(FileInputStream fis = new FileInputStream(cwd + "\\" + nextLineArray[1]);
                FileOutputStream fos = new FileOutputStream(cwd + "\\" + nextLineArray[2])) {
                int b;
                while((b = fis.read()) != -1) {
                    fos.write(b);
                }

                fis.close();
                fos.close();
            }
            catch(IOException ioException) {
                System.out.println("Ktorys lub oba z podanych plikow nie istnieja");
            }
        }
        else {
            System.out.println("cp - niepoprawna ilosc argumentow");
        }
    }

    private void mkdir(String[] nextLineArray) {
        if(nextLineArray.length == 2) {
            new File(cwd + "\\" + nextLineArray[1]).mkdirs();
        }
        else {
            System.out.println("mkdir - niepoprawna liczba argumentow");
        }
    }

    private void rm(String[] nextLineArray) {
        if(nextLineArray.length > 1) {
            File f;
            /* Iterujemy po liscie plikow do usuniecia */
            for(String filename : nextLineArray) {
                f = new File(cwd + "\\" + filename);
                if(f.exists()) {
                    f.delete();
                }
            }
        }
        else {
            System.out.println("rm - niepoprawna liczba argumentow");
        }
    }

    private void head(String[] nextLineArray) {
        if(nextLineArray.length == 2) {
            try(BufferedReader fileToRead = new BufferedReader(new FileReader(cwd + "\\" + nextLineArray[1]))) {
                String line;
                int i = 1;
                while((line = fileToRead.readLine()) != null) {
                    System.out.println(line);
                    i++;
                    if(i == 10) break;
                }
            }
            catch(IOException ioException) {
                System.out.println("Plik o podanej nazwie nie istnieje");
            }
        }
        else {
            System.out.println("head - niepoprawna liczba argumentow");
        }
    }

    private void tail(String[] nextLineArray) {
        if(nextLineArray.length == 2) {
            try(BufferedReader fileToRead = new BufferedReader(new FileReader(cwd + "\\" + nextLineArray[1]))) {
                ArrayList<String> lastTenLines = new ArrayList<>();
                String line;
                int i;
                while((line = fileToRead.readLine()) != null) {
                    lastTenLines.add(line);
                }
                for(i=lastTenLines.size()-11; i<lastTenLines.size()-1; i++) {
                    System.out.println(lastTenLines.get(i));
                }
            }
            catch(IOException ioException) {
                System.out.println("Plik o podanej nazwie nie istnieje");
            }
        }
        else {
            System.out.println("tail - niepoprawna liczba argumentow");
        }
    }

    private void commandNotFound(String command) {
        System.out.println("Nie odnaleziono polecenia " + command);
    }

    /* Glowna metoda klasy */
    public int start() {
        Scanner scanner = new Scanner(System.in);
        String command, nextLine;
        String[] nextLineArray;
        ArrayList<String> commandsList = new ArrayList<>();

        while(true) {
            /* Poczatek linii - sciezka biezacego katalogu */
            System.out.print(cwd + " > ");

            /* Pobieramy dane od uzytkownika z klawiatury i zapisujemy je do odpowiednich zmiennych */
            nextLine = scanner.nextLine();
            nextLineArray = nextLine.split(" ");
            command = nextLineArray[0];

            /* Zapisujemy uzyta komende do listy (dla polecenia history) */
            commandsList.add(nextLine);

            /* Wykonuemy polecenie */
            switch(command) {
                case "exit":
                    return 0;
                case "pwd":
                    pwd(nextLineArray);
                    break;
                case "ls":
                    ls(nextLineArray);
                    break;
                case "cd":
                    cd(nextLineArray);
                    break;
                case "cat":
                    cat(nextLineArray);
                    break;
                case "history":
                    history(commandsList);
                    break;
                case "echo":
                    echo(nextLine);
                    break;
                case "cp":
                    cp(nextLineArray);
                    break;
                case "mkdir":
                    mkdir(nextLineArray);
                    break;
                case "rm":
                    rm(nextLineArray);
                    break;
                case "head":
                    head(nextLineArray);
                    break;
                case "tail":
                    tail(nextLineArray);
                    break;
                default:
                    commandNotFound(nextLineArray[0]);
                    break;
            }
        }
    }
}