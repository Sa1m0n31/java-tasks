import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class CalculationsServlet extends HttpServlet {
    public boolean isNumber(String str) {
        if(str == null) return false;
        try {
            int d = Integer.parseInt(str);
        }
        catch(NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public List<String> splitInput(String input) {
        return Arrays.asList(input.split(" "));
    }

    public double doubleOperations(double a, double b, String operation) {
        switch (operation) {
            case "+":
                return b + a;
            case "-":
                return b - a;
            case "*":
                return b * a;
            case "/":
                return b / a;
            default:
                return 0;
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int i;
        double a, b, result;
        String operation;
        boolean error = false;
        List<String> allSymbols;
        Stack<Double> stack = new Stack<>();

        /* Pobieramy wartosc z formularza */
        String input = req.getParameter("onp");

        /* Zapisujemy wartosci liczb i znakow do listy */
        allSymbols = splitInput(input);

        /* Dla kazdego elementu tablicy - jesli liczba: odluz na stos, jesli znak: oblicz wartosc wyrazenia dla dwoch ostatnich liczb na stosie */
        for(i=0; i<allSymbols.size(); i++) {
            if(isNumber(allSymbols.get(i))) {
                stack.push((double) Integer.parseInt(allSymbols.get(i)));
            }
            else {
                if(!stack.empty()) a = stack.pop();
                else {
                    error = true;
                    break;
                }
                if(!stack.empty()) b = stack.pop();
                else {
                    error = true;
                    break;
                }

                operation = allSymbols.get(i);

                if((operation.equals("+"))||(operation.equals("-"))||(operation.equals("*"))||(operation.equals("/"))) {
                    stack.push(doubleOperations(a, b, operation));
                }
                else {
                    error = true;
                    break;
                }
            }
        }

        /* Po petli powinien byc jeden element na stosie - wynik */
        if(error) {
            resp.getWriter().println("Wyrazenie niepoprawne");
        }
        else {
            result = stack.pop();
            if(stack.empty()) resp.getWriter().println(result);
            else resp.getWriter().println("Wyrazenie niepoprawne");
        }
    }
}
