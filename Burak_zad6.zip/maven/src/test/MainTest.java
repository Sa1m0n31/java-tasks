import org.junit.Test;

import static org.junit.Assert.*;

public class MainTest {
    /* Sprawdzamy obliczenia na liczbach rzeczywistych */
    @Test
    public void testRealCalculations() {
        CalculationsServlet testServlet = new CalculationsServlet();
        assertEquals(5.5, testServlet.doubleOperations(2, 11, "/"), 0.0001);
    }

    /* Sprawdzamy czy wyrazenie poprawnie dzieli sie na poszczegolne elementy */
    @Test
    public void testONPParsing() {
        CalculationsServlet testServlet = new CalculationsServlet();
        assertEquals("+", testServlet.splitInput("2 31 + 7 13").get(2));
        assertEquals("12", testServlet.splitInput("7 8 + 13 12").get(4));
        assertEquals(5, testServlet.splitInput("1 2 * 3 4").size());
    }

    /* Sprawdzamy czy funkcja isNumber() zwraca oczekiwane wartosci */
    @Test
    public void testIsNumber() {
        CalculationsServlet testServlet = new CalculationsServlet();
        assertTrue(testServlet.isNumber("55"));
        assertFalse(testServlet.isNumber("+"));
    }
}
