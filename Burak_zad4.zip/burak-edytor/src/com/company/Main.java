package com.company;

import javax.swing.*;
import java.text.Normalizer;

public class Main {

    public static void main(String[] args) {
        FirstForm form = new FirstForm();
        form.start();
    }
}
