package com.company;

public class Stats {
    public int numberOfCharacters;
    public int numberOfWords;
    public int numberOfLines;

    public static int charactersCounter(String text) {
        return text.length();
    }

    public static int wordsCounter(String text) {
        int i, counter = 0;
        for(i=0; i<text.length(); i++) {
            if(((i > 0)&&(text.charAt(i) != ' ')&&(text.charAt(i-1) == ' '))||((text.charAt(0) != ' ')&&(i == 0))) {
                counter++;
            }
        }
        return counter;
    }

    public static int linesCounter(String text) {
        int i, counter = 0;
        for(i=0; i<text.length(); i++) {
            if(text.charAt(i) == '\n') {
                counter++;
            }
        }
        return counter+1;
    }
}
