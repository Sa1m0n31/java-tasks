package com.company;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.BadLocationException;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class FirstForm {

    class ResizeListener extends ComponentAdapter {
        public void componentResized(ComponentEvent e) {
           if(editors != null) {
               for(int i=0; i<editors.size(); i++) {
                   editors.get(i).setSize(new Dimension((int) (frame.getWidth() * 0.8), frame.getHeight()));
               }
           }
        }
    }

    private boolean closeApp;

    private int currenntTabIndex;
    private String clipboard;

    private JPanel firstForm;
    public JFrame frame;
    public JPopupMenu contextMenu;

    public JMenuBar menuBar;
    public JMenu plikMenu, helpMenu;
    public JMenuItem newFile, open, save, close, helpMenuItem, closeEditor;
    public JMenuItem copy, paste;
    public JFileChooser fileChooser, saveFileChooser;
    public JTabbedPane tabbedPane;
    public JButton showStatsBtn;

    public ArrayList<JPanel> panels;
    public ArrayList<JEditorPane> editors;
    public ArrayList<File> files;
    public ArrayList<Boolean> isEdited;
    public ArrayList<JPanel> statsArray;
    public ArrayList<JButton> showStatsButtons;
    public ArrayList<JLabel> numbersOfCharactersLabel, numbersOfWordsLabel, numbersOfLinesLabel;

    void showContextMenu(MouseEvent me) {
        if(me.isPopupTrigger()) {
            contextMenu.show(me.getComponent(), me.getX(), me.getY());
        }
    }

    public FirstForm() {
        frame = new JFrame("Okno");
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        frame.addComponentListener(new ResizeListener());
        frame.setSize(new Dimension(800, 600));

        /* Brak plikow - currentTabIndex ustawiamy na -1 */
        currenntTabIndex = -1;

        closeApp = false;

        menuBar = new JMenuBar();
        contextMenu = new JPopupMenu();
        plikMenu = new JMenu("Plik");
        helpMenu = new JMenu("Pomoc");

        newFile = new JMenuItem("Nowy plik");
        open = new JMenuItem("Wczytaj");
        save = new JMenuItem("Zapisz");
        close = new JMenuItem("Zamknij");
        closeEditor = new JMenuItem("Zakończ");

        helpMenuItem = new JMenuItem("Wyświetl pomoc");

        copy = new JMenuItem("Kopiuj");
        paste = new JMenuItem("Wklej");

        showStatsBtn = new JButton("Pokaż statystyki");

        panels = new ArrayList<>();
        editors = new ArrayList<>();
        files = new ArrayList<>();
        isEdited = new ArrayList<>();
        statsArray = new ArrayList<>();
        showStatsButtons = new ArrayList<>();
        numbersOfCharactersLabel = new ArrayList<>();
        numbersOfWordsLabel = new ArrayList<>();
        numbersOfLinesLabel = new ArrayList<>();

        fileChooser = new JFileChooser();
        saveFileChooser = new JFileChooser();

        plikMenu.add(newFile);
        plikMenu.add(open);
        plikMenu.add(save);
        plikMenu.add(close);
        plikMenu.addSeparator();
        plikMenu.add(closeEditor);

        helpMenu.add(helpMenuItem);

        contextMenu.add(copy);
        contextMenu.add(paste);

        menuBar.add(plikMenu);
        menuBar.add(helpMenu);

        frame.add(firstForm);
        frame.setJMenuBar(menuBar);

        /* Wyswietl pomoc */
        helpMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String helpText = "Program Notatnik służy do edycji plików tekstowych.\n" +
                        "W celu utworzenia nowego pliku tekstowego wybierz z menu Plik opcje Nowy plik\n" +
                        "W celu edycji istniejacego pliku tekstowego wybierz z menu Plik opecje Otwórz i wybierz odpowiedni plik\n" +
                        "W celu zapisu danego pliku przejdź do edycji pliku (wybierz odpowiednią zakładkę na górze okna) i kliknij zapisz\n" +
                        "W celu usunięcia pliku z edytora przejdź do edycji pliku (wybierz odpowiednią zakładkę na górze okna) i kliknij zamknij\n" +
                        "W celu sprawdzenia statystyk edytowanego pliku kliknij przycisk 'Sprawdź statystyki' po prawej stronie okna\n" +
                        "Autor: Szymon Burak";

                JDialog helpDialog = new JDialog();
                JPanel helpPanel = new JPanel();
                JTextArea helpTextLabel = new JTextArea(helpText);

                helpTextLabel.setEditable(false);
                helpPanel.setBorder(new LineBorder(Color.WHITE, 10, true));

                helpPanel.setLayout(new BoxLayout(helpPanel, BoxLayout.Y_AXIS));
                helpPanel.add(helpTextLabel);

                helpDialog.add(helpPanel);
                helpDialog.setLocation((int) (frame.getWidth() * 0.5 - 250), (int) (frame.getHeight() * 0.5 - 250));
                helpDialog.setSize(800, 500);
                helpDialog.setVisible(true);
            }
        });

        /* Kopiuj do schowka zaznaczony tekst */
        copy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JEditorPane currentEditor = editors.get(currenntTabIndex);
                String selectedText = currentEditor.getSelectedText();
                if(selectedText != null) {
                    clipboard = selectedText;
                }
            }
        });

        /* Wklej do edytora zawartosc schowka */
        paste.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    JEditorPane currentEditor = editors.get(currenntTabIndex);
                    currentEditor.getDocument().insertString(currentEditor.getCaretPosition(), clipboard, null);
                } catch (BadLocationException badLocationException) {
                    badLocationException.printStackTrace();
                }
            }
        });

        /* NOWY PLIK */
        newFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                afterOpenFile(null);
            }
        });

        /* OTWARCIE PLIKU */
        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Otwieramy FileChoosera z mozliwoscia wyboru pliku do edycji */
                fileChooser.showOpenDialog(frame);
            }
        });

        /* ZAPIS PLIKU */
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(currenntTabIndex >= 0) {
                    saveFile(currenntTabIndex);
                }
            }
        });

        /* ZAMKNIECIE PLIKU */
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if((currenntTabIndex >= 0)&&(isEdited.get(currenntTabIndex))) {
                    /* Upewniamy sie, czy uzytkownik na pewno chce zamknac plik */
                    int dialogResult = JOptionPane.showConfirmDialog(frame, "Czy na pewno chcesz usunąć plik z edytora?");
                    if(dialogResult != JOptionPane.YES_OPTION) return;
                }
                /* Zamykamy plik */
                tabbedPane.remove(currenntTabIndex);
            }
        });

        /* ZAMKNIECIE APLIKACJI */
        closeEditor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* Jesli ktorykolwiek z plikow byl edytowany i nie zostal zapisany - zapytaj o zgode na zamkniecie */
                boolean showCloseWarning = false;
                int i;
                for(i=0; i<isEdited.size(); i++) {
                    if(isEdited.get(i)) {
                        showCloseWarning = true;
                        break;
                    }
                }

                if(showCloseWarning) {
                    int dialogResult = JOptionPane.showConfirmDialog(frame, "Czy na pewno chcesz zamknac aplikacje?");

                    if(dialogResult != JOptionPane.YES_OPTION) return;
                }

                frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
            }
        });

        /* Po otwarciu pliku */
        fileChooser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                afterOpenFile(fileChooser.getSelectedFile());
            }
        });

        /* Zmiana aktualnie edytowanego pliku */
        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                currenntTabIndex = tabbedPane.getSelectedIndex();
            }
        });

        /* Zamkniecie aplikacji przez nacisniecie przycisku 'x' w prawym gornym rogu */
        frame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {

            }

            @Override
            public void windowClosing(WindowEvent e) {
                if(!closeApp) {
                    /* Checboxy - poszczegolne pliki */
                    ArrayList<JCheckBox> checkboxes = new ArrayList<>();
                    int i;
                    for(i=0; i<files.size(); i++) {
                        if(isEdited.get(i)) checkboxes.add(new JCheckBox(files.get(i).getName()));
                    }

                    /* Jesli mamy wiecej niz dwa modyfikowane i nie zapisane pliki - otworz okno z lista niezapisanych plikow */
                    if(checkboxes.size() >= 2) {
                        JLabel unsavedInfo = new JLabel("Następujące pliki pozostają niezapisane:");
                        JLabel unsavedQuestion = new JLabel("Wybierz, które z nich zapisać");

                        JButton saveBtn = new JButton("Zapisz");
                        JButton closeBtn = new JButton("Nie zapisuj");

                        JDialog unsavedList = new JDialog(frame, "Lista", true);
                        JPanel unsavedPanel = new JPanel();
                        JPanel buttonsPanel = new JPanel();
                        unsavedPanel.setLayout(new BoxLayout(unsavedPanel, BoxLayout.Y_AXIS));

                        unsavedPanel.add(unsavedInfo);

                        for(i=0; i<checkboxes.size(); i++) {
                            unsavedPanel.add(checkboxes.get(i));
                        }

                        unsavedPanel.add(unsavedQuestion);

                        buttonsPanel.add(saveBtn);
                        buttonsPanel.add(closeBtn);
                        unsavedPanel.add(buttonsPanel);

                        unsavedList.add(unsavedPanel);

                        saveBtn.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                /* Zapisz wszystkie zaznaczone pliki */
                                for(int i=0; i<checkboxes.size(); i++) {
                                    if(checkboxes.get(i).isSelected()) {
                                        int fileIndex = getFileIndexByName(checkboxes.get(i).getText());
                                        if(fileIndex >= 0) {
                                            saveFile(fileIndex);
                                        }
                                    }
                                }

                                /* Zamknij aplikacje */
                                closeApp = true;
                                frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
                            }
                        });

                        closeBtn.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                /* Zamknij aplikacje */
                                closeApp = true;
                                frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
                            }
                        });

                        unsavedList.setSize(400, 400);
                        unsavedList.setLocation((int) (frame.getWidth() * 0.5 - 200), (int) (frame.getHeight() * 0.5 - 200));
                        unsavedList.setVisible(true);
                    }
                    else {
                        closeApp = true;
                        frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
                    }

                }
                else {
                    frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSED));
                }
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });

    }

    void afterOpenFile(File choosenFile) {
        panels.add(new JPanel());
        editors.add(new JEditorPane());
        statsArray.add(new JPanel());
        isEdited.add(Boolean.FALSE);

        showStatsButtons.add(new JButton("Pokaż statystyki"));
        numbersOfCharactersLabel.add(new JLabel("Liczba znaków:"));
        numbersOfWordsLabel.add(new JLabel("Liczba słów:"));
        numbersOfLinesLabel.add(new JLabel("Liczba linii:"));

        int currentEditor = editors.size() - 1;

        editors.get(currentEditor).setSize(new Dimension((int) (frame.getWidth() * 0.8), frame.getHeight()));

        /* Otwieranie menu kontekstowego */
        editors.get(currentEditor).addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                showContextMenu(e);
            }
        });

        /* Wyswietlanie statystyk */
        showStatsButtons.get(currentEditor).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String currentEditorText = editors.get(currenntTabIndex).getText();

                numbersOfCharactersLabel.get(currenntTabIndex).setText("Liczba znaków: " + Stats.charactersCounter(currentEditorText));
                numbersOfWordsLabel.get(currenntTabIndex).setText("Liczba wyrazów: " + Stats.wordsCounter(currentEditorText));
                numbersOfLinesLabel.get(currenntTabIndex).setText("Liczba linii: " + Stats.linesCounter(currentEditorText));
            }
        });

        /* Wykrywanie zmian dokonywanych w edytowanym pliku */
        editors.get(editors.size()-1).addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                isEdited.set(currenntTabIndex, true);
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        if(choosenFile != null) {
            try {
                /* Czytanie pliku i napisanie jego aktualnej tresci w edytorze */
                StringBuilder stringBuilder = new StringBuilder("");
                String s1;

                FileReader fileReader = new FileReader(choosenFile);
                BufferedReader bufferedReader = new BufferedReader(fileReader);

                files.add(choosenFile);

                while((s1 = bufferedReader.readLine()) != null) {
                    stringBuilder.append(s1);
                    stringBuilder.append("\n");
                }

                editors.get(currentEditor).setText(stringBuilder.toString());

            } catch (IOException fileNotFoundException) {
                fileNotFoundException.printStackTrace();
            }
        }
        else {
            /* Nowy plik */
            File newFile = new File("nowy-plik.txt");
            files.add(newFile);
            choosenFile = newFile;
        }

        JPanel currentStatsArray = statsArray.get(currentEditor);

        currentStatsArray.setSize(new Dimension((int) (frame.getWidth() * 0.15), frame.getHeight()));
        currentStatsArray.setAlignmentX((float) 0.8);
        currentStatsArray.setLayout(new BoxLayout(currentStatsArray, BoxLayout.Y_AXIS));
        currentStatsArray.add(numbersOfCharactersLabel.get(currentEditor));
        currentStatsArray.add(numbersOfWordsLabel.get(currentEditor));
        currentStatsArray.add(numbersOfLinesLabel.get(currentEditor));
        currentStatsArray.add(showStatsButtons.get(currentEditor));

        panels.get(currentEditor).add(editors.get(currentEditor));
        panels.get(currentEditor).add(statsArray.get(currentEditor));
        tabbedPane.addTab(choosenFile.getName(), panels.get(panels.size()-1));
    }

    void saveFile(int fileIndex) {
        /* 1. Otwieramy okno z mozliwoscia wyboru pliku do zapisu */
        saveFileChooser.setSelectedFile(files.get(fileIndex));
        int userSelection = saveFileChooser.showSaveDialog(frame);

        /* 2. Sprawdzamy czy uzytkownik wybral opcje zapisz w FileChooserze */
        if(userSelection == JFileChooser.APPROVE_OPTION) {
            try {
                /* 3. Pobieramy plik z JFileChoosera i tworzymy FileWritera */
                File fileToSave = saveFileChooser.getSelectedFile();
                FileWriter fileWriterToSave = new FileWriter(fileToSave.getAbsolutePath());

                /* 4. Pobieramy edytowana tresc i zapisujemy ja do FileWritera */
                fileWriterToSave.write(editors.get(fileIndex).getText());

                /* 5. Zamykamy zapisany plik */
                fileWriterToSave.close();

                /* 6. Zmieniamy informacje o tym, czy plik byl edytwany i nie zapisany */
                isEdited.set(fileIndex, false);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        }
    }

    int getFileIndexByName(String fileName) {
        int i;
        for(i=0; i<files.size(); i++) {
            if(files.get(i).getName().equals(fileName)) return i;
        }
        return -1;
    }

    public void start() {
        frame.setVisible(true);
    }
}
