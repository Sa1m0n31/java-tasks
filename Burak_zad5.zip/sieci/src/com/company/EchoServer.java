package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class EchoServer {
    public static ArrayList<String> listOfNicks;
    public static ArrayList<ClientHandler> clientThreads;

    public static boolean isNickAvailable(String nick) {
        int i;
        for(i=0; i<listOfNicks.size(); i++) {
            if(nick.equals(listOfNicks.get(i))) return false;
        }
        return true;
    }

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(3456);
        listOfNicks = new ArrayList<>();
        clientThreads = new ArrayList<>();

        while(true) {
            Socket socket;
            socket = serverSocket.accept();

            /* Tworzymy nowy watek dla nowego klienta */
            Thread t = new Thread(() -> {
                int i;
                String nick = "";
                int clientId = 0;
                    try(BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                        String line, msg;
                        boolean nickAssigned = false;
                        while((line = br.readLine()) != null) {
                           if(!nickAssigned) {
                               /* Pierwsza linia - pobieramy nick */
                               if(isNickAvailable(line)) {
                                   nick = line;
                                   listOfNicks.add(nick);
                                   clientThreads.add(new ClientHandler(socket));
                                   clientId = clientThreads.size()-1;
                                   nickAssigned = true;
                                   msg = "Dolaczyles do czatu. Napisz '<exit>' by opuścić czat";

                                   /* Klientowi udalo sie dolaczyc do czatu - wysylamy o tym informacje do pozostalych klientow */
                                   for(i=0; i<clientThreads.size(); i++) {
                                       if(i != clientId) {
                                           clientThreads.get(i).msg = nick + " dolaczyl do czatu";
                                           clientThreads.get(i).run();
                                       }
                                   }
                               }
                               else {
                                   msg = "Nick zajety. Wybierz inny.";
                               }

                               /* Wysylamy informacje do klienta o tym czy link jest wolny */
                               socket.getOutputStream().write(msg.getBytes());
                               socket.getOutputStream().write(System.lineSeparator().getBytes());
                               socket.getOutputStream().flush();
                           }
                           else {
                              /* Nick zostal juz przydzielony - odczytujemy wiadomosc od klienta */
                              if(line.equals("<exit>")) msg = nick + " opuscil czat";
                              else msg = "[" + nick + "]: " + line;

                              /* Wysylamy ja do wszystkich klientow oprocz wysylajacego */
                              for(i=0; i<clientThreads.size(); i++) {
                                  if(i != clientId) {
                                      clientThreads.get(i).msg = msg;
                                      clientThreads.get(i).run();
                                  }
                              }
                           }


                        }
                    }
                    catch(IOException e) {
                        e.printStackTrace();
                    }

            });
            t.start();
        }
    }
}
