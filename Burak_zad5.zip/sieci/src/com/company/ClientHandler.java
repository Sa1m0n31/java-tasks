package com.company;

import java.io.IOException;
import java.net.Socket;

public class ClientHandler extends Thread {
    Socket socket;
    String msg;

    ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        super.run();

        /* Wysylamy informacje do klienta o komunikacie */
        try {
            socket.getOutputStream().write(msg.getBytes());
            socket.getOutputStream().write(System.lineSeparator().getBytes());
            socket.getOutputStream().flush();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
}
