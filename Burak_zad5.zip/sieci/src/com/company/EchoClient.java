package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class EchoClient {
    public static void main(String[] args) throws IOException {
        try(Socket socket = new Socket("localhost", 3456)) {
            /* Watek pobierajacy informacje od serwera */
            Thread t = new Thread(() -> {
                try(BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                    String line;
                    while((line = bufferedReader.readLine()) != null) {
                        System.out.println(line);
                    }
                } catch (IOException ioException) {
                    if(!socket.isClosed()) {
                        ioException.printStackTrace();
                    }
                }
            });
            t.start();

            /* Laczenie z serwerem - pobieranie nicku, a nastepnie wiadomosci */
            System.out.println("Witaj w czacie. Wpisz swoj nick:");
            Scanner scanner = new Scanner(System.in);
            OutputStream os = socket.getOutputStream();
            while(scanner.hasNextLine()) {
                String line = scanner.nextLine();
                os.write(line.getBytes());
                os.write(System.lineSeparator().getBytes());
                os.flush();
                if(line.equals("<exit>")) break; // Opuszczanie czatu
            }
            System.out.println("Oposciles czat");

            t.interrupt();
        }
    }
}