package com.company;

public class Kolo {
    double r;

    public Kolo(double r) {
        this.r = r;
    }

    public boolean czyPunktJestWewnatrz(double x, double y) {
        /* Odleglosc punktu (x, y) od srodka ukladu wspolrzednych musi byc mniejsza
           badz rowna promieniowi
        */
        return Math.sqrt(x*x + y*y) <= r;
    }
}
