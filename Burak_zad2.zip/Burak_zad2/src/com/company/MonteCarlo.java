package com.company;

public class MonteCarlo {
    public static Kolo circle = new Kolo(1);

    public static void main() {
        int i, numberOfTimesInsideCircle = 0;
        double x, y;

        /* Losujemy wspolrzedne z przedzialu [0, 1) i sprawdzamy czy znajduja sie wewnatrz okregu */
        for(i=0; i<100000; i++) {
            x = Math.random();
            y = Math.random();

            if(circle.czyPunktJestWewnatrz(x, y)) {
                numberOfTimesInsideCircle++;
            }
        }

        /* Mnozymy przez 4 i dzielimy przez 100 000 */
        System.out.println((double) numberOfTimesInsideCircle * 4 / (double) 100000);
    }
}
