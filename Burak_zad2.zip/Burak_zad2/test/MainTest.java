import com.company.Kolo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MainTest {
    /* Srodek wspolrzednych powinien znajdowac sie wewnatrz kola o promieniu 5 */
    @Test
    void testInside() {
        Kolo circle = new Kolo(5);
        assertTrue(circle.czyPunktJestWewnatrz(0, 0));
    }

    /* Punkt (3, 4) powinien znajdowac sie na zewnatrz kola o promieniu 3.9 */
    @Test
    void testOutside() {
        Kolo circle = new Kolo(3.9);
        assertFalse(circle.czyPunktJestWewnatrz(3, 4));
    }
}
